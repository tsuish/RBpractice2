package Main;
import java.awt.*;
import java.awt.event.*;
import Manager.*;
import javax.swing.ImageIcon;  
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;  
import javax.swing.JLabel;  
import javax.swing.JPanel;  
import javax.swing.JPasswordField;  
import javax.swing.JTextField;
public class Login {//��¼����
	public Login() {
		Login.jiemian();
//		Login.demo();
		
	}
//	public static void demo(){   by����
////		String str[]={"����Ա","��Ա"};
//		JFrame jf=new JFrame("��Ա����ϵͳ");
//		JPanel mainpane=new JPanel();
//		JPanel top=new JPanel();
//		JPanel left=new JPanel();
//		JPanel right=new JPanel();
//		JPanel bot=new JPanel();
//		JLabel loglab=new JLabel("���¼��");
//		JLabel idlab=new JLabel("�˺ţ�");
//		JLabel pawdlab=new JLabel("���룺");
//		JTextField id=new JTextField(10);
//		JPasswordField passtext=new JPasswordField(10);
//		JButton logbut=new JButton("��¼");
////		JComboBox jcb=new JComboBox(str);
//		top.add(loglab);
//		top.setOpaque(false);
//		left.setLayout(new GridLayout(2,1));
//		left.add(idlab);
//		left.add(pawdlab);
//		left.setOpaque(false);
//		right.setLayout(new GridLayout(2,1));
//		right.add(id);
//		right.add(passtext);
//		right.setOpaque(false);
//		bot.add(logbut);
//		bot.setOpaque(false);
//		FreedomPane freedompane=new FreedomPane();
//		freedompane.setLayout(new BorderLayout());
//		freedompane.add(top,BorderLayout.NORTH);
//		freedompane.add(left,BorderLayout.WEST);
//		freedompane.add(right, BorderLayout.CENTER);
//		freedompane.add(bot, BorderLayout.SOUTH);
//		mainpane.add(freedompane);
//		mainpane.setLayout(new CardLayout());
//		jf.setContentPane(mainpane);
//		jf.setSize(500, 150);
//		//ʹ���ھ�����ʾ
//		Toolkit tk=Toolkit.getDefaultToolkit();
//		Dimension  sc=tk.getScreenSize();//��ȡ��Ļ�ߴ�
//		jf.setBounds(sc.width/4, sc.height/4, 500, 150);
////		jf.setResizable(false);
//		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		jf.setVisible(true);
//	}
	public static void jiemian(){
		JFrame jframe=new JFrame("��Ա����ϵͳ");
		JPanel jp1=new JPanel();
		JPanel jp2=new JPanel();
		JPanel jp3=new JPanel();
		JPanel jp4=new JPanel();
		JPanel jp5=new JPanel();
		JPanel jp6=new JPanel();
		jp1.setOpaque(false);
		jp2.setOpaque(false);
		jp3.setOpaque(false);
		jp4.setOpaque(false);
		jp5.setOpaque(false);
		jp6.setOpaque(false);
		JLabel lab1=new JLabel("��Ա������½",JLabel.CENTER);
		JLabel lab2=new JLabel("",JLabel.CENTER);
		JLabel lab3=new JLabel("",JLabel.CENTER);
		JLabel lab4=new JLabel("",JLabel.CENTER);
		JLabel lab5=new JLabel("����:  ",JLabel.CENTER);
		JButton b=new JButton("��¼");
//		String str[]={"����Ա"};
//		JComboBox<String> box=new JComboBox<String>(str);
		
		JTextField t1=new JTextField("",15);
		JPasswordField t2=new JPasswordField("",15);
		t2.setEchoChar('*');  
		ImageIcon icon1=new ImageIcon("ͷ.jpg");
		ImageIcon icon2=new ImageIcon("��.jpg");
		System.out.println(System.getProperty("user.dir"));
		
		
		lab3.setIcon(icon1);
		lab4.setIcon(icon2);
		
		jp1.add(lab1);
		jp2.add(lab2);
		jp3.add(lab3);
		jp3.add(t1);
		jp4.add(lab4);
		jp4.add(t2);
		jp6.add(b);
		FreedomPane freedompane=new FreedomPane();
		freedompane.setLayout(new GridLayout(6,1));
		freedompane.add(jp1);
		freedompane.add(jp2);
		freedompane.add(jp3);
		freedompane.add(jp4);
		freedompane.add(jp5);
		freedompane.add(jp6);
		JPanel mainpane=new JPanel();
		mainpane.add(freedompane);
		mainpane.add(freedompane);
		mainpane.setLayout(new CardLayout());
		jframe.setContentPane(mainpane);
		//ʹ���ھ�����ʾ
		Toolkit tk=Toolkit.getDefaultToolkit();
		Dimension  sc=tk.getScreenSize();//��ȡ��Ļ�ߴ�
		jframe.setBounds(400, 300,400,300);
		b.setForeground(Color.GREEN);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true);
		
		
		
		
		b.addActionListener(new ActionListener() {//
			public void actionPerformed(ActionEvent e) {
				String user=t1.getText();
				String pass=new String(t2.getPassword());
				//String identity=(String)box.getSelectedItem();
				Login_Check_Function date=new Login_Check_Function(user,pass);
				boolean flag = date.prepared();
				if(user.equals("")){
					lab2.setForeground(Color.RED);
					lab2.setText("�������ʺţ�����");
				}else if(pass.equals("")){
					lab2.setForeground(Color.RED);
					lab2.setText("���������룡����");
				}else if (flag) { 										//�ж��Ƿ�Ϊ�Ϸ��û�
					new Manager_Login();
					jframe.dispose();						//���ص�ǰ����
					lab2.setForeground(Color.GREEN);
					lab2.setText("��¼�ɹ�������");
				} else if (!flag){
					lab2.setForeground(Color.RED);
					lab2.setText("�˺Ż�������󣡣���");
				}
			}
		});
	}
}