package Manager;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class Manager_AllUser_Query_Function {//������Vip_AllUser��"��"
	public Manager_AllUser_Query_Function(){
		JFrame jframe=new JFrame("ȫ���û�_���Ų�ѯ");
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel();
		JPanel p5=new JPanel();
		JPanel p6=new JPanel();
		JPanel p7=new JPanel();
		JPanel p8=new JPanel();
		JPanel p9=new JPanel();
		JPanel p10=new JPanel();
		JPanel p11=new JPanel();
		JPanel p12=new JPanel();
		JLabel u11 = new JLabel("��         �ţ�");
		p1.setOpaque(false);
		p2.setOpaque(false);
		p3.setOpaque(false);
		p4.setOpaque(false);
		p5.setOpaque(false);
		p6.setOpaque(false);
		p7.setOpaque(false);
		p8.setOpaque(false);
		p9.setOpaque(false);
		p10.setOpaque(false);
		p11.setOpaque(false);
		p12.setOpaque(false);
		
		JLabel u12 = new JLabel("��Ա��    ��");
		JLabel u13 = new JLabel("��         ����"); 						
		JLabel u14 = new JLabel("��         �룺"); 					
		JLabel u15 = new JLabel("��         ����"); 									
		JLabel u16 = new JLabel("�쿨ʱ�䣺");
		JLabel u17 = new JLabel("������");
		JLabel u18 = new JLabel("��Ա����"); 						
		JLabel u19 = new JLabel("��         �֣�"); 					
		JLabel u20 = new JLabel("�Ƽ���    ��"); 
		
		
		JTextField t11 = new JTextField("", 20); 							
		JTextField t12 = new JTextField("", 20); 						
		JTextField t13 = new JTextField("", 20); 					
		JTextField t14 = new JTextField("", 20); 							
		JTextField t15 = new JTextField("", 20);
		JTextField t16 = new JTextField("", 20);
		JTextField t17 = new JTextField("", 20); 							
		JTextField t18 = new JTextField("", 20); 						
		JTextField t19 = new JTextField("", 20); 					
		JTextField t20 = new JTextField("", 20);
		JButton b1=new JButton("�û���ѯ");
		JButton b2=new JButton("��");

		p1.add(u11);
		p1.add(t11);
		p2.add(u12);
		p2.add(t12);
		p3.add(u13);
		p3.add(t13);
		p4.add(u14);
		p4.add(t14);
		p5.add(u15);
		p5.add(t15);
		p6.add(u16);
		p6.add(t16);
		p7.add(u17);
		p7.add(t17);
		p8.add(u18);
		p8.add(t18);
		p9.add(u19);
		p9.add(t19);
		p10.add(u20);
		p10.add(t20);
		p11.add(b1);
		p12.add(b2);

		FreedomPane freedompane=new FreedomPane();
		freedompane.setLayout(new GridLayout(12, 1));
		freedompane.add(p1);
		freedompane.add(p11);
		freedompane.add(p2);
		freedompane.add(p3);
		freedompane.add(p4);
		freedompane.add(p5);
		freedompane.add(p6);
		freedompane.add(p7);
		freedompane.add(p8);
		freedompane.add(p9);
		freedompane.add(p10);
		freedompane.add(p12);
		JPanel mainpane=new JPanel();
		mainpane.add(freedompane);
		mainpane.setLayout(new CardLayout());
		jframe.setContentPane(mainpane);
		jframe.setBounds(400,100,600,600);
		b1.addActionListener(new ActionListener() {//�û���ѯ
			
			
			public void actionPerformed(ActionEvent e) {
				String id=t11.getText();
				Object[] os=Manager_AllUser_Change_Function.iddquery(id);
				t11.setText((String)os[0]);
				t12.setText((String)os[1]);
				t13.setText((String)os[2]);
				t14.setText((String)os[3]);
				t15.setText((String)os[4]);
				t16.setText((String)os[5]);
				t17.setText((String)os[6]);
				t18.setText((String)os[7]);
				t19.setText((String)os[8]);
				t20.setText((String)os[9]);
			}
		});
		b2.addActionListener(new ActionListener() {//��
			public void actionPerformed(ActionEvent e) {
				new Manager_User_AllUser();
				jframe.dispose();
			}
		});
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true);
	}
}