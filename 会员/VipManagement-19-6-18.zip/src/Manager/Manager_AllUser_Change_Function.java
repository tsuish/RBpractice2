package Manager;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;
import java.sql.*;
public class Manager_AllUser_Change_Function {////������Vip_AllUser��"��"
	public Manager_AllUser_Change_Function(String id){
		JFrame jframe=new JFrame("ȫ���û�_�޸��û�");
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel();
		JPanel p5=new JPanel();
		JPanel p6=new JPanel();
		JPanel p7=new JPanel();
		JPanel p8=new JPanel();
		JPanel p9=new JPanel();
		JPanel p10=new JPanel();
		JPanel p11=new JPanel();
		p1.setOpaque(false);
		p2.setOpaque(false);
		p3.setOpaque(false);
		p4.setOpaque(false);
		p5.setOpaque(false);
		p6.setOpaque(false);
		p7.setOpaque(false);
		p8.setOpaque(false);
		p9.setOpaque(false);
		p10.setOpaque(false);
		p11.setOpaque(false);
		JLabel u11 = new JLabel("��         �ţ�");
		JLabel u12 = new JLabel("��Ա��    ��");
		JLabel u13 = new JLabel("��         ����"); 						
		JLabel u14 = new JLabel("��         �룺"); 					
		JLabel u15 = new JLabel("��         ����"); 									
		JLabel u16 = new JLabel("�쿨ʱ�䣺");
		JLabel u17 = new JLabel("������");
		JLabel u18 = new JLabel("��Ա����"); 						
		JLabel u19 = new JLabel("��         �֣�"); 					
		JLabel u20 = new JLabel("�Ƽ���    ��"); 
		
		
		JTextField t11 = new JTextField("", 20); 							
		JTextField t12 = new JTextField("", 20); 						
		JTextField t13 = new JTextField("", 20); 					
		JTextField t14 = new JTextField("", 20); 							
		JTextField t15 = new JTextField("", 20);
		JTextField t16 = new JTextField("", 20);
		JTextField t17 = new JTextField("", 20); 							
		JTextField t18 = new JTextField("", 20); 						
		JTextField t19 = new JTextField("", 20); 					
		JTextField t20 = new JTextField("", 20);
		t11.setEditable(false);
		
        
		JButton b1=new JButton("ȷ���޸�");
		JButton b2=new JButton("��");
		
		Object[] os=Manager_AllUser_Change_Function.iddquery(id);
		t11.setText((String)os[0]);
		t12.setText((String)os[1]);
		t13.setText((String)os[2]);
		t14.setText((String)os[3]);
		t15.setText((String)os[4]);
		t16.setText((String)os[5]);
		t17.setText((String)os[6]);
		t18.setText((String)os[7]);
		t19.setText((String)os[8]);
		t20.setText((String)os[9]);
		
		
		p1.add(u11);
		p1.add(t11);
		p2.add(u12);
		p2.add(t12);
		p3.add(u13);
		p3.add(t13);
		p4.add(u14);
		p4.add(t14);
		p5.add(u15);
		p5.add(t15);
		p6.add(u16);
		p6.add(t16);
		p7.add(u17);
		p7.add(t17);
		p8.add(u18);
		p8.add(t18);
		p9.add(u19);
		p9.add(t19);
		p10.add(u20);
		p10.add(t20);
		p11.add(b2);
		p11.add(b1);
		
		FreedomPane freedompane=new FreedomPane();
		freedompane.setLayout(new GridLayout(11, 1));
		freedompane.add(p1);
		freedompane.add(p2);
		freedompane.add(p3);
		freedompane.add(p4);
		freedompane.add(p5);
		freedompane.add(p6);
		freedompane.add(p7);
		freedompane.add(p8);
		freedompane.add(p9);
		freedompane.add(p10);
		freedompane.add(p11);
		JPanel mainpane=new JPanel();
		mainpane.add(freedompane);
		mainpane.setLayout(new CardLayout());
		//����С�������
		CalendarPanel_Function pp3 = new CalendarPanel_Function(t16, "yyyy-MM-dd");
        pp3.initCalendarPanel(400);
        jframe.getContentPane().add(pp3);
		jframe.setContentPane(mainpane);
		jframe.setBounds(400,100,600,600);
		t16.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e){
        		t16.setText("");
        	}
		});
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				String s1=t11.getText();
				String s2=t12.getText();
				String s3=t13.getText();
				String s4=t14.getText();
				String s5=t15.getText();
				String s6=t16.getText();
				String s7=t17.getText();
				String s8=t18.getText();
				String s9=t19.getText();
				String s10=t20.getText();
				if(s1==null||"".equals(s1)||
					s2==null||"".equals(s2)||
					s3==null||"".equals(s3)||
					s4==null||"".equals(s4)||
					s5==null||"".equals(s5)||
					s6==null||"".equals(s6)||
					s7==null||"".equals(s7)||
					s8==null||"".equals(s8)||
					s9==null||"".equals(s9)||
					s10==null||"".equals(s10)){																		//�ж�������Ϣ�Ƿ���ȷ
						JOptionPane.showMessageDialog(null, "�û���Ϣ������󣡣���",
								"�����ʾ��Ϣ���", JOptionPane.INFORMATION_MESSAGE);
						return;
					}
				
				
				if(Manager_AllUser_Change_Function.update( s2, s3, s4, s5, s6, s7, s8, s9, s10,s1)>0){
					
					JOptionPane.showMessageDialog(null, "�޸��û���Ϣ�ɹ���",
							"�����ʾ��Ϣ���", JOptionPane.INFORMATION_MESSAGE);
				}else{
					JOptionPane.showMessageDialog(null, "�޸��û���Ϣʧ�ܣ�����",
							"�����ʾ��Ϣ���", JOptionPane.INFORMATION_MESSAGE);
				}
				new Manager_User_AllUser();
				jframe.dispose();
			}
		});
		
		
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Manager_User_AllUser();
				jframe.dispose();
			}
		});
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true);
	}

	public static int update(String s1,String s2,String s3,String s4,String s5,String s6,String s7,String s8,String s9,String s10){
		Connection conn=null;
		PreparedStatement ps=null;
		int rows=0;
		try{
			conn=DBConnection.getConnection();
			String sql="update vipadminis set VipAdminis_No=?,VipAdminis_Name=?,Vip_passwd=?,VipAdminis_Tel=?,"+
						"VipAdminis_Time=?,VipAdminis_Money=?,VipAdminis_Level=?,VipAdminis_Score=?,Vip_peo=? where Vip_No=?";
			ps=conn.prepareStatement(sql);
			ps.setString(1,s1);
			ps.setString(2,s2);
			ps.setString(3,s3);
			ps.setString(4,s4);
			ps.setString(5,s5);
			ps.setString(6,s6);
			ps.setString(7,s7);
			ps.setString(8,s8);
			ps.setString(9,s9);
			ps.setString(10,s10);
			//ps.setString(11,id);
			rows=ps.executeUpdate();
		}catch(Exception e){
			JOptionPane.showMessageDialog(null, "�޸�����ʱ�����쳣������",
					"�����ʾ��Ϣ���", JOptionPane.INFORMATION_MESSAGE);
			e.printStackTrace();
		}finally{
			DBConnection.close(ps);
			DBConnection.close(conn);
		}
		return rows;
		
	}
	
	public static Object[] iddquery(String id){
		Object[] os=new Object[10];
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
			conn=DBConnection.getConnection();
			String sql="select Vip_No,VipAdminis_No,VipAdminis_Name,Vip_passwd,VipAdminis_Tel,"
						+ "VipAdminis_Time,VipAdminis_Money,VipAdminis_Level,VipAdminis_Score,Vip_peo from VipAdminis WHERE Vip_No=?";
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
				if(rs.next()){
					os[0] = rs.getString(1); 							//����
					os[1] = rs.getString(2); 							//��Ա��
					os[2] = rs.getString(3); 							//����
					os[3] = rs.getString(4); 							//����
					os[4] = rs.getString(5); 							//�绰
					os[5] = rs.getString(6); 							//�쿨ʱ��
					os[6] = rs.getString(7); 							//���
					os[7] = rs.getString(8);							//����
					os[8] = rs.getString(9);							//����
					os[9] = rs.getString(10);
				}
				
		}catch (SQLException e){
			JOptionPane.showMessageDialog(null, "��ѯuserָ���û���Ϣʱ�����쳣", "�����ʾ��Ϣ���",
					JOptionPane.INFORMATION_MESSAGE);
					e.printStackTrace();
		}finally{
			DBConnection.close(conn);
		}
		return os;	
	}
	
	
}
