package Manager;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;
import Manager.Manager_User_AllUser;

public class Manager_In_Change_Function {//�޸����Ѽ�¼
	public Manager_In_Change_Function(String id){
		JFrame jframe=new JFrame("�޸Ĵ�ֵ��¼");
		JPanel p1=new JPanel();
		JPanel p2=new JPanel();
		JPanel p3=new JPanel();
		JPanel p4=new JPanel();
		JPanel p5=new JPanel();

		JLabel u11 = new JLabel("��         �ţ�");
		JLabel u12 = new JLabel("��         ����"); 						
		JLabel u13 = new JLabel("��ֵ��"); 												
		JLabel u14 = new JLabel("ʱ        �䣺");


		JTextField t11 = new JTextField("", 20); 							
		JTextField t12 = new JTextField("", 20); 						
		JTextField t13 = new JTextField("", 20); 					
		JTextField t14 = new JTextField("", 20); 							
		JButton b1=new JButton("ȷ���޸�");
		JButton b2=new JButton("����");

		Object[] os=Manager_In_Change_Function.iddquery(id);
		t11.setText((String)os[0]);
		t12.setText((String)os[1]);
		t13.setText((String)os[2]);
		t14.setText((String)os[3]);
		
		
		p1.add(u11);
		p1.add(t11);
		p2.add(u12);
		p2.add(t12);
		p3.add(u13);
		p3.add(t13);
		p4.add(u14);
		p4.add(t14);
		
		p5.add(b1);
		p5.add(b2);
		
		
		jframe.setLayout(new GridLayout(11, 1));
		jframe.add(p1);
		jframe.add(p2);
		jframe.add(p3);
		jframe.add(p4);
		jframe.add(p5);
		
		
		
		
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
		
		
		
		String s1=t11.getText();
		String s2=t12.getText();
		String s3=t13.getText();
		String s4=t14.getText();
		
		
		if(Manager_In_Change_Function.update(s2, s3, s4,s1)>0){
			
			JOptionPane.showMessageDialog(null, "�޸��û���Ϣ�ɹ���",
					"�����ʾ��Ϣ���", JOptionPane.INFORMATION_MESSAGE);
		}else{
			JOptionPane.showMessageDialog(null, "�޸��û���Ϣʧ�ܣ�����",
					"�����ʾ��Ϣ���", JOptionPane.INFORMATION_MESSAGE);
					}
					
				}
			});
			
			
			b2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new Manager_User_AllUser();
					jframe.dispose();
				}
			});
			jframe.setSize(400,600);
			jframe.setLocation(400,100);
			jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jframe.setVisible(true);
		}
	
	
	public static int update(String s1,String s2,String s3,String s4){//��  ���ѱ�
	Connection conn=null;
	PreparedStatement ps=null;
	int rows=0;
	try{
		conn=DBConnection.getConnection();
		String sql="update vipin set VipAdminis_Name=?,Vip_Money=?,Vip_Time=? where Vip_No=?";
		ps=conn.prepareStatement(sql);
		ps.setString(1,s1);
		ps.setString(2,s2);
		ps.setString(3,s3);
		ps.setString(4,s4);
		
		rows=ps.executeUpdate();
	}catch(Exception e){
		JOptionPane.showMessageDialog(null, "�޸�����ʱ�����쳣������",
				"�����ʾ��Ϣ���", JOptionPane.INFORMATION_MESSAGE);
		e.printStackTrace();
	}finally{
		DBConnection.close(ps);
		DBConnection.close(conn);
	}
	return rows;
	
}
	
	public static Object[] iddquery(String id){//�޸����Ѽ�¼
		Object[] os=new Object[5];
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
			conn=DBConnection.getConnection();
			String sql="select Vip_No,VipAdminis_Name,Vip_Money,Vip_Time from Vipin WHERE Vip_No=?";
			ps=conn.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
				if(rs.next()){
					os[0] = rs.getString(1); 							//����
					os[1] = rs.getString(2); 							//����
					os[2] = rs.getString(3); 							//���ѽ��
					os[3] = rs.getString(4); 							//ʱ��
				}
				
		}catch (SQLException e){
			JOptionPane.showMessageDialog(null, "��ѯuserָ����ֵ��¼��Ϣʱ�����쳣", "�����ʾ��Ϣ���",
					JOptionPane.INFORMATION_MESSAGE);
					e.printStackTrace();
		}finally{
			DBConnection.close(conn);
		}return os;
	}
	
	
}
