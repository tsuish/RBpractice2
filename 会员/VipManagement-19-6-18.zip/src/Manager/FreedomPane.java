package Manager;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class FreedomPane extends JPanel{//���ÿɱ任��С����ͼ
	String path="����.jpg";
	  //��дJPanel�е�paintComponent�������Ʊ���ͼ
	    public void paintComponent(Graphics g){
	    	super.paintComponent(g);
	        ImageIcon image=new ImageIcon(path);  
	        //��ȡͼƬ�����  
	        int width=getWidth();
	        int height=getHeight();  
	        g.drawImage(image.getImage(), 0,0,width,height,this);  
	    }
//	    FreedomPane freedompane=new FreedomPane();
//		freedompane.setLayout(new GridLayout(6,1));
//		freedompane.add(jp1);
//		freedompane.add(jp2);
//		freedompane.add(jp3);
//		freedompane.add(jp4);
//		freedompane.add(jp5);
//		freedompane.add(jp6);
//		JPanel mainpane=new JPanel();
//		mainpane.add(freedompane);
//		mainpane.setLayout(new CardLayout());
//		jframe.setContentPane(mainpane);
//		//ʹ���ھ�����ʾ
//		Toolkit tk=Toolkit.getDefaultToolkit();
//		Dimension  sc=tk.getScreenSize();//��ȡ��Ļ�ߴ�
//		jframe.setBounds(sc.width/4, sc.height/4, 500, 150);
}
