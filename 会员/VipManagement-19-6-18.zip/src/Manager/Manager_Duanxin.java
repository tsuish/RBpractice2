package Manager;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Manager_Duanxin {
	public Manager_Duanxin(){
		JFrame jframe=new JFrame("��Ա_����");
		
		JLabel lab1=new JLabel("���ܴ�����",JLabel.CENTER);
		JPanel p=new JPanel();
		p.setOpaque(false);
		JButton b=new JButton("ȷ��");
		p.add(b);
		FreedomPane freedompane=new FreedomPane();
		freedompane.setLayout(new GridLayout(2, 1));
		freedompane.add(lab1);
		freedompane.add(p);
		JPanel mainpane=new JPanel();
		mainpane.add(freedompane);
		mainpane.setLayout(new CardLayout());
		jframe.setContentPane(mainpane);
		//ʹ���ھ�����ʾ
		Toolkit tk=Toolkit.getDefaultToolkit();
		Dimension  sc=tk.getScreenSize();//��ȡ��Ļ�ߴ�
		jframe.setBounds(400,300,400,300);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jframe.dispose();
			}
		});
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true);
		
	}
}
