package Manager;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import java.util.Vector;
import javax.swing.*;
import java.sql.*;
public class Manager_Tongjishuju_AllMoney{//�����
	public static void allmoney(){
		JFrame jframe=new JFrame("��Ա_ͳ������_�����");
		JLabel lab1=new JLabel("",JLabel.CENTER);
		JLabel lab2=new JLabel("",JLabel.CENTER);
		JPanel p=new JPanel();
		p.setOpaque(false);
		JButton b=new JButton("ȷ��");
		p.add(b);
		double a[]=Manager_Tongjishuju_AllMoney.allmoney_Function();
		String str1="�û�����"+a[0]+"Ԫ";
		int c=(int)a[1];
		String str2="�û���������"+c+"��";
		lab1.setText(str1);
		lab2.setText(str2);
		Font font=new Font("����",Font.BOLD,25);
		lab1.setForeground(Color.GREEN);
		lab1.setFont(font);
		lab2.setForeground(Color.GREEN);
		lab2.setFont(font);
		FreedomPane freedompane=new FreedomPane();
		freedompane.setLayout(new GridLayout(3, 1));
		freedompane.add(lab1);
		freedompane.add(lab2);
		freedompane.add(p);
		JPanel mainpane=new JPanel();
		mainpane.add(freedompane);
		mainpane.setLayout(new CardLayout());
		jframe.setContentPane(mainpane);
		//ʹ���ھ�����ʾ
		Toolkit tk=Toolkit.getDefaultToolkit();
		Dimension  sc=tk.getScreenSize();//��ȡ��Ļ�ߴ�
		jframe.setBounds(400,300,400,300);
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jframe.dispose();
			}
		});
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true);
	}
	
	public static double[] allmoney_Function(){
//		Vector<Object> vv=new Vector<Object>();
//		Vector<Object> v = new Vector<Object>();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		double[] a=new double[2];
		a[0]=0.0;//sum
		a[1]=0.0;//i
		try{
			conn=DBConnection.getConnection();
			String sql="select Vip_No,VipAdminis_Money from vipadminis";
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
				
				while(rs.next()){
					a[0]+=rs.getDouble(2);
					a[1]+=1.0;
				}
				
		}catch (SQLException e){
					System.out.println("��ѯ����ʱ�����쳣������");
					e.printStackTrace();
		}finally{
			DBConnection.close(conn);
		}
		return a;
	}
}
