package Manager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import Main.Login;
public class Manager_Login {
	public Manager_Login(){
		JFrame jframe=new JFrame("����Աģ��");
		ImageIcon icon=new ImageIcon("timg.jpg");
		JLabel la=new JLabel(icon);

		jframe.add(la);
		jframe.setResizable(false);
		JMenuBar mb=new JMenuBar();
		jframe.setJMenuBar(mb);
		JMenu m1=new JMenu("�û�");
		JMenu m2=new JMenu("ͳ������");
		JMenuItem m21=new JMenuItem("�����");
		JMenuItem m22=new JMenuItem("���ѱ�");
		JMenuItem m23=new JMenuItem("��ֵ��");
		JMenu m3=new JMenu("����");
		JMenuItem m31=new JMenuItem("����");
		JMenu m4=new JMenu("���µ�¼");
		JMenuItem m41=new JMenuItem("���µ�¼");
		m2.add(m21);
		m2.add(m22);
		m2.add(m23);
		m3.add(m31);
		m4.add(m41);
		JMenuItem mi6=new JMenuItem("ȫ���û�");
		

		m1.add(mi6);
		mb.add(m1);
		mb.add(m2);
		mb.add(m3);
		mb.add(m4);
		jframe.setLocation(400, 100);
		jframe.setSize(600,600);
		
	
		mi6.addActionListener(new ActionListener() {//"ȫ���û�"
			public void actionPerformed(ActionEvent e) {
				new Manager_User_AllUser();
				jframe.dispose();
			}
		});
		m21.addActionListener(new ActionListener() {//"�����"
			public void actionPerformed(ActionEvent e) {
				Manager_Tongjishuju_AllMoney.allmoney();
			}
		});
		m22.addActionListener(new ActionListener() {//"���ѱ�"
			public void actionPerformed(ActionEvent e) {
				new Manager_Tongjishuju_OutMoney();
				jframe.dispose();
			}
		});
		m23.addActionListener(new ActionListener() {//"��ֵ��"
			public void actionPerformed(ActionEvent e) {
				new Manager_Tongjishuju_InMoney();
				jframe.dispose();
			}
		});
		m31.addActionListener(new ActionListener() {//"����"
			public void actionPerformed(ActionEvent e) {
				new Manager_Duanxin();
			}
		});
		m41.addActionListener(new ActionListener() {//"���µ�¼"
			public void actionPerformed(ActionEvent e) {
				new Login();
				jframe.dispose();
			}
		});
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setVisible(true);
		
	}
}
